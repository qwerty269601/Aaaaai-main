from collections import deque
def Water(Jug1,Jug2,Target):
    queue=deque([(0,0)])
    visited=set()
    while queue:
        a,b=queue.popleft()
        if (a,b) in visited:
            continue
        visited.add((a,b))
        if(a==Target or b==Target):
            print("solution Found")
            print((a,b))
            return
        
        print("Current state",(a,b))
        state=[
            (Jug1,b),
            (a,Jug2),
            (0,b),
            (a,0),
            (
                a-min(a,Jug2-b),
                b+min(a,Jug2-b)
            ),
            (
                a+min(b,Jug1-a),
                b-min(b,Jug1-a)
            )
            
            
        ]
        for s in state:
            if s not in visited:
                queue.append(s)
        
    
Water(4,3,2)
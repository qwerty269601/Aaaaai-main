from collections import deque
def solve(jug1,jug2,Target):
    queue=deque([(0,0)])
    visited=set()
    while queue:
        a,b=queue.popleft()
        if (a, b) in visited:
            continue
        visited.add((a,b))
        print("Current State",(a,b))
        if(a==Target or b==Target):
         print("Target Found")
         return
        states=[
            (jug1,b),
            (a,jug2),
            (0,b),
            (a,b)
            (
                a-min(a,jug2-b),
                b+min(a,jug2-b)
            ),
            (
                a+min(b,jug1-a),
                b-min(b,jug1-a)
                
            )
        ]
        for state  in states:
            if state not in visited:
                queue.append(state)
            
        
solve(3,4,1)